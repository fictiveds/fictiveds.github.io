<?php
require __DIR__ . '/vendor/autoload.php';

use Kreait\Firebase\Factory;

// Проверка, была ли форма отправлена
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получение данных из формы
    $productName = $_POST['productName'];
    $productDescription = $_POST['productDescription'];
    $productPrice = $_POST['productPrice'];

    // Подключение к Firebase и получение экземпляра базы данных
    $factory = (new Factory)
        ->withServiceAccount(__DIR__.'/secret/potok-soznaniya-44709-firebase-adminsdk-nmuik-66d1832eec.json')
        ->withDatabaseUri('https://potok-soznaniya-44709-default-rtdb.europe-west1.firebasedatabase.app');
    $database = $factory->createDatabase();

    // Добавление данных в Firebase
    $newProductRef = $database->getReference('products')->push([
        'name' => $productName,
        'description' => $productDescription,
        'price' => $productPrice
    ]);

    echo 'Товар успешно добавлен!';
} else {
    // Если форма не отправлена, выводим сообщение об ошибке
    echo 'Ошибка: Форма не была отправлена.';
}
